import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class Ex02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try
		{
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(new File("C:\\Users\\hallym\\Desktop\\�������̷� �ǽ�(20175103, ������)\\University.xml"));
			NodeList list = doc.getElementsByTagName("dept_name");
			//NodeList childs = doc.getChildNodes();
			int i = 0;
			Element element;
			String contents, Nodename;
			while(list.item(i) != null)
			{
				element = (Element) list.item(i);
				contents = (element.getTextContent());
				System.out.println( element.getNodeName() + " : " + contents);
				i++;
			}
			
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

}
