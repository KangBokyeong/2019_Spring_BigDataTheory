import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import java.util.*;

public class Ex04 {
	public static void main(String[] args) throws SAXException, IOException, ParserConfigurationException {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();
		Document doc = builder.parse(
				"http://finlife.fss.or.kr/finlifeapi/annuitySavingProductsSearch.xml?auth=4c9325a70528cebbdacb935e307f0932&topFinGrpNo=050000&pageNo=1");

		NodeList list = doc.getElementsByTagName("result");
		int max_page = 0;
		
		//max_page_no ã��
		for (int i = 0; i < list.getLength(); i++) {
			for (Node node = list.item(i).getFirstChild(); node != null; node = node.getNextSibling()) {
				if (node.getNodeName().equals("max_page_no")) {
					max_page = Integer.parseInt(node.getTextContent());
				}
			}
		}
		// root ���ϱ�
		Element root = doc.getDocumentElement();
		
		for (int i1 = 1; i1 <= max_page; i1++) {
			doc = builder.parse(
					"http://finlife.fss.or.kr/finlifeapi/annuitySavingProductsSearch.xml?auth=4c9325a70528cebbdacb935e307f0932&topFinGrpNo=050000&pageNo="
							+ i1);
			System.out.println("page number : " + i1);
			System.out.println("Root element : " + root.getNodeName());
			System.out.println("######################################");
	
			

			list = doc.getElementsByTagName("product");
			for (int i = 0; i < list.getLength(); i++) {
		
				for (Node node = list.item(i).getFirstChild(); node != null; node = node.getNextSibling()) {

					// baseinfo �ȿ���
					if (node.getNodeName().equals("baseinfo")) {
						for (Node node2 = node.getFirstChild(); node2 != null; node2 = node2.getNextSibling()) {
							// ����ȸ���
							if (node2.getNodeName().equals("kor_co_nm")) {
								System.out.println("����ȸ��� : " + node2.getTextContent());
							}
							// ������ǰ�ڵ�
							else if (node2.getNodeName().equals("fin_prdt_cd")) {
								System.out.println("������ǰ�ڵ� : " + node2.getTextContent());
							}
							// ������ǰ��
							else if (node2.getNodeName().equals("fin_prdt_nm")) {
								System.out.println("������ǰ�� : " + node2.getTextContent());
							}
							// ���Թ��
							else if (node2.getNodeName().equals("join_way")) {
								System.out.println("���� ��� : " + node2.getTextContent());
							}
							// ��ǰ������
							else if (node2.getNodeName().equals("prdt_type_nm")) {
								System.out.println("��ǰ������ : " + node2.getTextContent());
							}
							// ����� ���ͷ�
							else if (node2.getNodeName().equals("avg_prft_rate")) {
								System.out.println("����� ���ͷ� : " + node2.getTextContent());
							}
							// ���� ����
							else if (node2.getNodeName().equals("dcls_rate")) {
								System.out.println("���� ���� : " + node2.getTextContent());
								System.out.println("######################################");
							}
						}

					}

				}
			}
		}

	}

}
