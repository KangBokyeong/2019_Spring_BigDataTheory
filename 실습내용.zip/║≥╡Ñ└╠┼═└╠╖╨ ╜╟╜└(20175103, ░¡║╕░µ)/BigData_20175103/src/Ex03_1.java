import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import java.util.*;

public class Ex03_1 {
	public static void main(String[] args) throws SAXException, IOException, ParserConfigurationException {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();
		Document doc = builder.parse("http://www.kma.go.kr/weather/forecast/mid-term-xml.jsp?");
		// xml���� ���
		
		NodeList list_of_location = doc.getElementsByTagName("location");

		Scanner input = new Scanner(System.in);
		System.out.print("�ְ� ������ �˰� ���� ���ø� �Է�: ");
		String input_location = input.next();
		int index = 0;
		// ���ϴ� ������ �Է� ������ �ϴ� �׿� ���� �ε��� ����
		for (int i = 0; i < list_of_location.getLength(); i++) {
			for (Node node = list_of_location.item(i).getFirstChild(); node != null; node = node.getNextSibling()) {
				if (node.getNodeName().equals("city")) {
					if (node.getTextContent()
							.equals(input_location)) {
						index = i;
					}
					
				}
			}
		}
		// ����� �ε����� ������ ������ �ϳ��� ���
		for (Node node = list_of_location.item(index).getFirstChild(); node != null; node = node.getNextSibling()) {
				if (node.getNodeName().equals("city")) {
					System.out.println("====" + node.getTextContent() + "====");
				}
				if (node.getNodeName().equals("data")) {
					for (Node node2 = node.getFirstChild(); node2 != null; node2 = node2.getNextSibling()) {
						if (node2.getNodeName().equals("tmEf")) {
							System.out.println(node2.getTextContent());
						} else if (node2.getNodeName().equals("wf")) {
							System.out.println(node2.getTextContent());
						} else if (node2.getNodeName().equals("tmn")) {
							System.out.println(node2.getTextContent());
						} else if (node2.getNodeName().equals("tmx")) {
							System.out.println(node2.getTextContent());
							System.out.println("----------");
						}					
				}
			}
		}

	}

}
